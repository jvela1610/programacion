import java.util.Scanner;

public class Ejercicio4 {

	public static Scanner teclado = new Scanner (System.in);
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int notapractica,notaproblemas,notateorica,notafinal;
		System.out.println("Dime tu nota practica");
		notapractica = Integer.parseInt(teclado.nextLine());
		System.out.println("Dime tu nota problemas");
		notaproblemas = Integer.parseInt(teclado.nextLine());
		System.out.println("Dime tu nota teorica");
		notateorica = Integer.parseInt(teclado.nextLine());
		
		
	}

}
